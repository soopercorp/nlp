function openPrintWindow(url)
{
	winPrint = window.open(url, 'articlePrint', "toolbar=no, location=no, directories=no, status=yes, menubar=no, resizable=yes, scrollbars=yes, width=300, height=300");
	return false;
}