if (this.lycos_ad["leaderboard"]) {
    document.write('</div>');
}

if (this.lycos_ad["leaderboard2"]) {
    document.write('<div align="center" id="FooterAd" name="FooterAd" style="display:none; left:0px; top:0px"><br clear="all">');
    document.write(this.lycos_ad["leaderboard2"]);
}
